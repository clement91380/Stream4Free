@file:Suppress("DEPRECATION")

val composeVersion = "1.5.1"  // Assurez-vous d'utiliser une version compatible avec Kotlin 1.9
val kotlinVersion = "1.9.10"  // La version Kotlin 1.9.10

plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.example.stream4life"
    compileSdk = 34

    defaultConfig {
        ndkVersion = "27.2.12479018"
        applicationId = "com.example.stream4life"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    viewBinding {
        enable = true
    }
    buildFeatures {
        dataBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Dépendances de base
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("com.google.android.material:material:1.11.0")
    implementation("com.github.bumptech.glide:glide:4.15.1")
    implementation("androidx.webkit:webkit:1.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.11.0")
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:4.11.0")

    // Jetpack Compose
    implementation("androidx.compose.ui:ui:$composeVersion")
    implementation("androidx.compose.material3:material3:1.1.0")
    implementation("androidx.compose.ui:ui-tooling-preview:$composeVersion")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.6.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.0")

    // LiveData et ViewModel
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.0")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.6.0")
    implementation(libs.play.services.drive)
    implementation(libs.androidx.animation.core)
    implementation(libs.androidx.foundation.layout)
    implementation(libs.androidx.foundation.layout)
    implementation(libs.androidx.constraintlayout.core)
    implementation(libs.androidx.animation.core.android)
    implementation(libs.androidx.constraintlayout.compose.android)
    implementation(libs.firebase.inappmessaging)
    implementation(libs.androidx.fragment)
    testImplementation(libs.junit.junit)

    // Tests
    androidTestImplementation("androidx.compose.ui:ui-test-junit4:$composeVersion")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    // Autres dépendances
    implementation("androidx.recyclerview:recyclerview:1.2.1")
    implementation("androidx.appcompat:appcompat:1.6.0")
    implementation("org.jetbrains.kotlin:kotlin-stdlib:$kotlinVersion")
    implementation("org.jsoup:jsoup:1.16.1")
    implementation("com.airbnb.android:lottie:5.0.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation ("com.squareup.okhttp3:okhttp:4.10.0")  // Vérifiez la dernière version d'OkHttp
    implementation ("com.squareup.okhttp3:logging-interceptor:4.10.0")
    val latest_version = "0.1.3"
    implementation ("com.github.islamdidarmd:AdBlockerWebview:$latest_version")
    implementation("com.github.darkryh:NoMoreAdsOnMyWebViewPlayer:0.1.1")
    implementation ("androidx.compose.foundation:foundation:1.5.1")
    implementation ("androidx.navigation:navigation-compose:2.7.3")
    implementation ("com.google.code.gson:gson:2.10")


}
