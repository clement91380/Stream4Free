package com.example.stream4life.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Définition des couleurs
val Purple80 = Color(0xFFD0BCFF) // Couleur claire pour le thème sombre
val PurpleGrey80 = Color(0xFFCCC2DC) // Couleur secondaire claire
val Pink80 = Color(0xFFEFB8C8) // Couleur tertiaire claire
val Purple40 = Color(0xFF6650a4) // Couleur principale pour le thème clair
val PurpleGrey40 = Color(0xFF625b71) // Couleur secondaire pour le thème clair
val Pink40 = Color(0xFF7D5260) // Couleur tertiaire pour le thème clair

// Définition du schéma de couleurs pour le thème sombre
private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

// Définition du schéma de couleurs pour le thème clair
private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40
)

@Composable
fun Stream4LifeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Sélection des couleurs en fonction du mode sombre ou clair
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        LightColorScheme
    }

    // Application du thème avec les couleurs choisies
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography, // Typographie à définir si besoin
        content = content
    )
}
