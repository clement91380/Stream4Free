package com.example.stream4life

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.ead.lib.nomoreadsonmywebviewplayer.NoMoreAdsWebView
import com.ead.lib.nomoreadsonmywebviewplayer.core.Blocker
import com.ead.lib.nomoreadsonmywebviewplayer.models.BlockerClient

class SeriesPlayerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series_player)

        // Initialiser le bloqueur d'annonces
        Blocker.init(this)

        val webView = findViewById<NoMoreAdsWebView>(R.id.web_view)
        val listViewLinks = findViewById<ListView>(R.id.listViewLinks)

        // Récupérer les liens vidéo depuis l'intent
        val videoLinks = intent.getStringArrayListExtra("VIDEO_LINKS") ?: emptyList()

        // Adapter pour afficher les liens vidéo
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, videoLinks)
        listViewLinks.adapter = adapter

        // Événement sur le clic d'un lien vidéo
        listViewLinks.setOnItemClickListener { _, _, position, _ ->
            val selectedLink = videoLinks[position]
            playVideoInWebView(webView, selectedLink)
        }

        // Lire automatiquement le premier lien vidéo si disponible
        if (videoLinks.isNotEmpty()) {
            playVideoInWebView(webView, videoLinks[0])
        }
    }

    private fun playVideoInWebView(webView: NoMoreAdsWebView, url: String) {
        // Configuration du WebView pour les liens "embed"
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.mediaPlaybackRequiresUserGesture = false

        // Associer un BlockerClient au WebView
        webView.webViewClient = BlockerClient()

        // Charger l'URL dans le WebView
        webView.loadUrl(url)
    }
}
