package com.example.stream4life

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.ead.lib.nomoreadsonmywebviewplayer.NoMoreAdsWebView
import com.ead.lib.nomoreadsonmywebviewplayer.core.Blocker

@Suppress("DEPRECATION")
class PlayerActivity : AppCompatActivity() {

    private lateinit var webView: NoMoreAdsWebView
    private lateinit var cursor: View  // Vue représentant le curseur
    private lateinit var cursorContainer: FrameLayout  // Conteneur du curseur
    private var cursorX = 0f  // Position X du curseur
    private var cursorY = 0f  // Position Y du curseur
    private val cursorStep = 20f  // Pas de déplacement du curseur

    private var selectedUrl: String? = null  // Lien sélectionné

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player) // Remplace par ton layout XML

        // Initialisation du bloqueur d'annonces
        Blocker.init(this)

        // Initialiser le WebView personnalisé
        webView = findViewById(R.id.web_view)

        // Initialiser le curseur
        cursor = findViewById(R.id.cursor)
        cursorContainer = findViewById(R.id.cursor_box) // Assurez-vous que le layout parent a cet ID

        // Positionner le curseur au centre initialement
        cursor.post {
            cursorX = (cursorContainer.width / 2).toFloat()
            cursorY = (cursorContainer.height / 2).toFloat()
            moveCursor(cursorX, cursorY)
        }

        // Récupérer l'URL sélectionnée via l'intent
        selectedUrl = intent.getStringExtra("selectedUrl")

        if (!selectedUrl.isNullOrEmpty()) {
            // Charger l'URL dans le WebView
            webView.loadUrl(selectedUrl!!)
        } else {
            Toast.makeText(this, "Aucun lien vidéo disponible", Toast.LENGTH_SHORT).show()
            finish() // Quitte l'activité si aucun lien n'est disponible
        }
    }

    // Méthode pour déplacer le curseur
    private fun moveCursor(newX: Float, newY: Float) {
        cursor.x = newX
        cursor.y = newY
    }

    // Gestion des touches de la télécommande
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                cursorY = (cursorY - cursorStep).coerceAtLeast(0f)
                moveCursor(cursorX, cursorY)
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                cursorY = (cursorY + cursorStep).coerceAtMost(cursorContainer.height.toFloat() - cursor.height)  // Evite que le curseur dépasse
                moveCursor(cursorX, cursorY)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                cursorX = (cursorX - cursorStep).coerceAtLeast(0f)
                moveCursor(cursorX, cursorY)
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                cursorX = (cursorX + cursorStep).coerceAtMost(cursorContainer.width.toFloat() - cursor.width)  // Evite que le curseur dépasse
                moveCursor(cursorX, cursorY)
                return true
            }
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER -> {
                // Simule un clic physique réel à l'emplacement actuel du curseur
                simulateRealClick(cursorX, cursorY)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // Simule un vrai clic physique à la position (x, y) dans le WebView
    private fun simulateRealClick(x: Float, y: Float) {
        // Créer un MotionEvent de type ACTION_DOWN à la position (x, y)
        val downEvent = MotionEvent.obtain(
            System.currentTimeMillis(),
            System.currentTimeMillis(),
            MotionEvent.ACTION_DOWN,
            x,
            y,
            0
        )

        // Créer un MotionEvent de type ACTION_UP pour indiquer la fin du clic
        val upEvent = MotionEvent.obtain(
            System.currentTimeMillis(),
            System.currentTimeMillis(),
            MotionEvent.ACTION_UP,
            x,
            y,
            0
        )

        // Dispatch les événements sur le WebView pour simuler un vrai clic
        webView.dispatchTouchEvent(downEvent)
        webView.dispatchTouchEvent(upEvent)
    }

    // Gestion de l'historique du WebView
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
