package com.example.stream4life

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

// L'adaptateur pour gérer la liste des séries
class SeriesAdapter(
    private var seriesList: List<Series>, // Liste des séries
    private val onSeriesClick: (Series) -> Unit // Callback de clic sur une série
) : RecyclerView.Adapter<SeriesAdapter.SeriesViewHolder>() {

    // ViewHolder pour l'élément individuel de la liste
    class SeriesViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.textViewSeriesTitle)
        val image: ImageView = view.findViewById(R.id.imageViewSeries)
        val playButton: View = view.findViewById(R.id.buttonPlaySeries)

        init {
            // Si l'une des vues est nulle, on lève une exception pour pouvoir la déboguer plus facilement
            if (title == null) throw NullPointerException("textViewSeriesTitle is null")
            if (image == null) throw NullPointerException("imageViewSeries is null")
            if (playButton == null) throw NullPointerException("buttonPlaySeries is null")
        }
    }

    // Méthode pour créer un ViewHolder pour chaque élément de la liste
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeriesViewHolder {
        // Gonfler le layout pour chaque item de la liste
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_series_card, parent, false) // Assurez-vous que le layout item_series_card est correct
        return SeriesViewHolder(view)
    }

    // Méthode pour lier les données de la série au ViewHolder
    override fun onBindViewHolder(holder: SeriesViewHolder, position: Int) {
        val series = seriesList[position]

        // Mettre à jour le titre de la série
        holder.title.text = series.title

        // Utilisation de Glide pour charger l'image de la série
        Glide.with(holder.itemView.context)
            .load(series.image_url) // L'URL de l'image de la série
            .placeholder(R.drawable.placeholder_image) // Image par défaut si l'URL est nulle ou si le téléchargement échoue
            .into(holder.image)

        // Gestion du clic sur l'élément
        holder.itemView.setOnClickListener { onSeriesClick(series) }

        // Gestion du clic sur le bouton "Lire"
        holder.playButton.setOnClickListener {
            // Ajoutez ici l'action à exécuter lorsque l'utilisateur clique sur "Lire"
            // Par exemple, lancer un lecteur vidéo ou ouvrir une autre activité
            onSeriesClick(series)
        }
    }

    // Retourner le nombre d'éléments dans la liste
    override fun getItemCount(): Int = seriesList.size

    // Méthode pour mettre à jour la liste et notifier l'adaptateur
    fun updateList(newList: List<Series>) {
        seriesList = newList
        notifyDataSetChanged() // Notifier que les données ont changé et que la vue doit être mise à jour
    }
}
