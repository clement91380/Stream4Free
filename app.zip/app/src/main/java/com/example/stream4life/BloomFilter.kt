package com.example.stream4life

class BloomFilter(val size: Int) {
    private val bitSet = BooleanArray(size)

    fun add(value: String) {
        val hash = value.hashCode()
        val index = Math.abs(hash % size) // S'assurer que l'indice est positif
        bitSet[index] = true
    }

    fun contains(value: String): Boolean {
        val hash = value.hashCode()
        val index = Math.abs(hash % size) // S'assurer que l'indice est positif
        return bitSet[index]
    }
}
