package com.example.stream4life

import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.stream4life.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity(), BottomNavigationView.OnNavigationItemSelectedListener {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation du binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ajouter le fragment par défaut (MoviesFragment)
        if (savedInstanceState == null) {
            loadFragment(MoviesFragment())
        }

        // Configurer le BottomNavigationView
        binding.bottomNavigationView.setOnNavigationItemSelectedListener(this)
    }

    /**
     * Méthode pour charger un fragment avec animation
     */
    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                android.R.anim.fade_in, // Animation entrée
                android.R.anim.fade_out // Animation sortie
            )
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    /**
     * Gestion des clics sur les items du menu de navigation
     */
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val fragment = when (item.itemId) {
            R.id.nav_movies -> MoviesFragment()
            R.id.nav_series -> SeriesFragment()
            R.id.nav_settings -> SettingsFragment()
            R.id.nav_info -> InfoFragment()
            else -> return false
        }
        loadFragment(fragment)
        return true
    }
}
