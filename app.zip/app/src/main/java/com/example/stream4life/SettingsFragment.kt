package com.example.stream4life

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.stream4life.databinding.FragmentSettingsBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class SettingsFragment : Fragment() {

    private lateinit var binding: FragmentSettingsBinding
    private lateinit var sharedPreferences: SharedPreferences

    // URL des mises à jour
    private val updateUrl = "https://stream-2-free.site/app/maj/"
    private val betaUpdateUrl = "https://stream-2-free.site/app/majbeta/"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Initialiser le layout avec le binding
        binding = FragmentSettingsBinding.inflate(inflater, container, false)

        // Initialiser les préférences partagées
        sharedPreferences = requireContext().getSharedPreferences("Stream4LifePrefs", 0)

        // Paramètre 1 : Gestion du mode clair/sombre
        binding.switchDarkMode.isChecked =
            sharedPreferences.getBoolean("darkMode", false) // Charger l'état initial
        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            savePreference("darkMode", isChecked)
        }

        // Paramètre 2 : Activer ou désactiver les notifications
        binding.switchNotifications.isChecked =
            sharedPreferences.getBoolean("notificationsEnabled", true)
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            savePreference("notificationsEnabled", isChecked)
            Toast.makeText(
                context,
                if (isChecked) "Notifications activées" else "Notifications désactivées",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Paramètre 3 : Gérer sa propre liste de films/séries
        binding.btnManageFavorites.setOnClickListener {
            Toast.makeText(context, "Gestion des favoris à venir !", Toast.LENGTH_SHORT).show()
        }

        // Paramètre 4 : Vérification des mises à jour
        binding.btnCheckUpdates.setOnClickListener {
            checkForUpdates(updateUrl)
        }

        // Paramètre 5 : Mode mise à jour bêta
        binding.switchBetaUpdates.isChecked =
            sharedPreferences.getBoolean("betaUpdatesEnabled", false)
        binding.switchBetaUpdates.setOnCheckedChangeListener { _, isChecked ->
            savePreference("betaUpdatesEnabled", isChecked)
            val message = if (isChecked) {
                "Mode mise à jour bêta activé"
            } else {
                "Mode mise à jour standard activé"
            }
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }

        // Paramètre 6 : Synchroniser après mise à jour
        binding.btnSyncData.setOnClickListener {
            syncData()
        }

        // Paramètre 7 : Envoyer des commentaires via e-mail
        binding.btnSendFeedback.setOnClickListener {
            sendFeedbackEmail()
        }

        return binding.root
    }

    /**
     * Vérifie la présence de mises à jour via une URL donnée
     */
    private fun checkForUpdates(baseUrl: String) {
        val url = if (sharedPreferences.getBoolean("betaUpdatesEnabled", false)) {
            betaUpdateUrl
        } else {
            baseUrl
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"

                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    // Télécharger le fichier de mise à jour (on simule ici une synchronisation)
                    val updateFile = File(requireContext().filesDir, "update_file.zip")
                    updateFile.outputStream().use { output ->
                        connection.inputStream.copyTo(output)
                    }

                    // Synchroniser après la mise à jour
                    requireActivity().runOnUiThread {
                        Toast.makeText(
                            context,
                            "Mise à jour téléchargée et installée avec succès !",
                            Toast.LENGTH_SHORT
                        ).show()
                        syncData()
                    }
                } else {
                    requireActivity().runOnUiThread {
                        Toast.makeText(
                            context,
                            "Aucune mise à jour disponible.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    Toast.makeText(
                        context,
                        "Erreur lors de la vérification des mises à jour.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    /**
     * Synchronisation des données après une mise à jour
     */
    private fun syncData() {
        // Simuler la synchronisation des données avec le fichier mis à jour
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Exemple : lecture d'un fichier pour synchronisation (simulation)
                val updateFile = File(requireContext().filesDir, "update_file.zip")
                if (updateFile.exists()) {
                    // Supposons que la synchronisation soit basée sur ce fichier
                    requireActivity().runOnUiThread {
                        Toast.makeText(
                            context,
                            "Synchronisation terminée avec succès !",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    requireActivity().runOnUiThread {
                        Toast.makeText(
                            context,
                            "Aucun fichier de mise à jour trouvé pour synchronisation.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    Toast.makeText(
                        context,
                        "Erreur lors de la synchronisation.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    /**
     * Envoyer un e-mail pour les retours
     */
    private fun sendFeedbackEmail() {
        val email = "stream2free.pecorio@gmail.com"
        val subject = "Feedback sur Stream4Life"
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(android.content.Intent.EXTRA_EMAIL, arrayOf(email))
            putExtra(android.content.Intent.EXTRA_SUBJECT, subject)
        }
        startActivity(
            android.content.Intent.createChooser(intent, "Envoyer un e-mail avec...")
        )
    }

    /**
     * Enregistrer une préférence dans SharedPreferences
     */
    private fun savePreference(key: String, value: Boolean) {
        with(sharedPreferences.edit()) {
            putBoolean(key, value)
            apply()
        }
    }
}
