package com.example.stream4life

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.stream4life.databinding.FragmentInfoBinding

class InfoFragment : Fragment() {

    private lateinit var binding: FragmentInfoBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Liaison avec le fichier XML via ViewBinding
        binding = FragmentInfoBinding.inflate(inflater, container, false)

        // Configuration du texte d'informations
        val infoText = """
            Je suis un jeune lycéen passionné par l'univers du développement web. Depuis plusieurs années, j'ai pris 
            l'initiative d'apprendre par moi-même, en explorant divers langages de programmation, frameworks et outils 
            nécessaires à la création de sites et d'applications web. Cette démarche autodidacte m'a permis d'acquérir 
            des compétences solides tout en nourrissant ma curiosité pour ce domaine en constante évolution.
            
            À travers mes projets personnels, j'ai pu développer une réelle expertise dans la conception de sites web 
            et l'optimisation de l'expérience utilisateur. Je souhaite mettre à profit ces connaissances dans un cadre 
            professionnel.
            
            Bien que je ne dispose pas encore d'un diplôme officiel, ma détermination et mon engagement à fournir un 
            travail de qualité me permettront de contribuer efficacement à des projets ambitieux.
            
            Mon objectif est de démontrer qu'avec passion et persévérance, il est possible de relever de grands défis.
        """.trimIndent()

        binding.tvInfo.text = infoText

        return binding.root
    }
}
