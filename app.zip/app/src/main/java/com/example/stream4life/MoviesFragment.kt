package com.example.stream4life

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.stream4life.databinding.FragmentMoviesBinding
import com.google.gson.Gson
import java.io.InputStream

class MoviesFragment : Fragment(R.layout.fragment_movies) {

    private var _binding: FragmentMoviesBinding? = null
    private val binding get() = _binding!!

    private val allMovies = mutableListOf<Movie>() // Liste complète des films
    private val displayedMovies = mutableListOf<Movie>() // Liste des films affichés (pagination)
    private var currentPage = 1
    private val moviesPerPage = 15
    private lateinit var adapter: MovieAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Initialisation de la liaison de vue
        _binding = FragmentMoviesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        loadMovies()
        updateDisplayedMovies()
        setupPagination()
        setupSearchBar()
    }

    /**
     * Configure le RecyclerView avec un adaptateur et un gestionnaire de disposition.
     */
    private fun setupRecyclerView() {
        adapter = MovieAdapter(displayedMovies, ::onMovieClick) // Initialisation de l'adaptateur
        binding.recyclerView.layoutManager = GridLayoutManager(requireContext(), 3) // Grille 3 colonnes
        binding.recyclerView.adapter = adapter
    }

    /**
     * Configure les boutons de pagination.
     */
    private fun setupPagination() {
        binding.nextPageButton.setOnClickListener {
            if ((currentPage * moviesPerPage) < allMovies.size) {
                currentPage++
                updateDisplayedMovies()
            }
        }

        binding.previousPageButton.setOnClickListener {
            if (currentPage > 1) {
                currentPage--
                updateDisplayedMovies()
            }
        }
    }

    /**
     * Configure la barre de recherche pour filtrer les films.
     */
    private fun setupSearchBar() {
        binding.searchBar.queryHint = "Rechercher un film..."
        binding.searchBar.isIconified = false
        binding.searchBar.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false

            override fun onQueryTextChange(newText: String?): Boolean {
                val filteredMovies = if (newText.isNullOrEmpty()) {
                    allMovies
                } else {
                    allMovies.filter { it.title.contains(newText, ignoreCase = true) }
                }
                updateDisplayedMovies(filteredMovies)
                return true
            }
        })
    }

    /**
     * Met à jour les films affichés en fonction de la page actuelle et de la liste filtrée.
     */
    private fun updateDisplayedMovies(filteredMovies: List<Movie> = allMovies) {
        val startIndex = (currentPage - 1) * moviesPerPage
        val endIndex = (startIndex + moviesPerPage).coerceAtMost(filteredMovies.size)

        displayedMovies.clear()
        displayedMovies.addAll(filteredMovies.subList(startIndex, endIndex))
        adapter.notifyDataSetChanged()
        updatePaginationText(filteredMovies.size)
    }

    /**
     * Met à jour le texte de la pagination en fonction du nombre total de films.
     */
    private fun updatePaginationText(totalMovies: Int) {
        val totalPages = (totalMovies + moviesPerPage - 1) / moviesPerPage
        binding.paginationText.text = "Page $currentPage / $totalPages"
    }

    /**
     * Gestion du clic sur un film : afficher un dialogue pour choisir un lien.
     */
    private fun onMovieClick(movie: Movie) {
        // Récupérer les liens vidéo disponibles pour le film
        val videoLinks = movie.links

        if (videoLinks.isEmpty()) {
            Toast.makeText(requireContext(), "Aucun lien disponible pour ce film", Toast.LENGTH_SHORT).show()
            return
        }

        // Afficher un dialogue pour que l'utilisateur choisisse un lien
        showVideoSelectionDialog(movie, videoLinks)
    }



    /**
     * Méthode pour afficher un dialogue de sélection du lien vidéo.
     * Elle retourne l'URL sélectionné par l'utilisateur ou `null` si aucun choix n'est fait.
     */
    private fun showVideoSelectionDialog(movie: Movie, links: List<Link>) {
        // Créez une liste des noms des services (ex. "Uqload", "Netu")
        val services = links.map { it.service }.toTypedArray()

        // Créez un dialogue pour afficher les services
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Sélectionnez une source")
        builder.setItems(services) { dialog, which ->
            // Récupérez l'URL sélectionnée
            val selectedUrl = links[which].url

            // Lancer l'activité PlayerActivity avec l'URL sélectionnée
            val intent = Intent(requireContext(), PlayerActivity::class.java).apply {
                putExtra("movie", movie) // Passez le film entier
                putExtra("selectedUrl", selectedUrl) // Passez l'URL sélectionnée
            }
            startActivity(intent)
        }
        builder.setNegativeButton("Annuler") { dialog, _ ->
            dialog.dismiss()
        }

        // Affichez le dialogue
        builder.create().show()
    }



    /**
     * Charge les films à partir d'un fichier JSON et les ajoute à la liste `allMovies`.
     */
    private fun loadMovies() {
        try {
            val inputStream: InputStream = requireContext().assets.open("film_results.json")
            val jsonReader = Gson().newJsonReader(inputStream.reader())

            // Début de l'objet JSON attendu (liste de films)
            jsonReader.beginArray()

            while (jsonReader.hasNext()) {
                // Lire chaque film individuellement et l'ajouter à la liste
                val movie = Gson().fromJson<Movie>(jsonReader, Movie::class.java)
                allMovies.add(movie)

                // Mettre à jour la liste affichée pour montrer les films au fur et à mesure
                if (allMovies.size % moviesPerPage == 0) {
                    updateDisplayedMovies()
                }
            }

            jsonReader.endArray() // Fin du tableau JSON
            jsonReader.close()   // Libérer les ressources

            // Mettre à jour l'affichage final (si des films restent)
            updateDisplayedMovies()

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Erreur lors du chargement des films", Toast.LENGTH_LONG).show()
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
