package com.example.stream4life

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.stream.JsonReader
import java.io.InputStream

// Classes de données
data class Episode(val number: String, val video_links: List<String>)
data class Season(val title: String, val episodes: List<Episode>)
data class Series(val title: String, val image_url: String, val seasons: List<Season>)

class SeriesFragment : Fragment(R.layout.fragment_series) {

    private lateinit var recyclerView: RecyclerView
    private var seriesList: MutableList<Series> = mutableListOf()

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Initialiser la vue du fragment
        val view = inflater.inflate(R.layout.fragment_series, container, false)

        // Initialiser le RecyclerView
        recyclerView = view.findViewById(R.id.recyclerViewSeries)
        recyclerView.layoutManager = LinearLayoutManager(context)

        // Charger les données JSON progressivement
        loadSeriesData()

        return view
    }

    // Charger les données JSON progressivement
    private fun loadSeriesData() {
        try {
            val inputStream: InputStream = requireContext().assets.open("series-results-formated.json")
            val jsonReader = JsonReader(inputStream.reader())

            // Début de l'objet JSON attendu (liste de séries)
            jsonReader.beginArray()

            while (jsonReader.hasNext()) {
                // Lire chaque série individuellement et l'ajouter à la liste
                val series = Gson().fromJson<Series>(jsonReader, Series::class.java)
                seriesList.add(series)

                // Mettre à jour l'adaptateur au fur et à mesure que les données arrivent
                recyclerView.adapter = SeriesAdapter(seriesList) { series ->
                    showSeasonDialog(series)
                }
            }

            jsonReader.endArray() // Fin du tableau JSON
            jsonReader.close()   // Libérer les ressources

        } catch (e: Exception) {
            e.printStackTrace()
            // Afficher une alerte en cas d'erreur
            AlertDialog.Builder(requireContext())
                .setTitle("Erreur de chargement")
                .setMessage("Impossible de charger les données des séries. Veuillez réessayer.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    // Afficher la popup des saisons
    private fun showSeasonDialog(series: Series) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_select_season, null)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()

        val listView = dialogView.findViewById<ListView>(R.id.lvSeasons)
        listView.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            series.seasons.map { it.title }
        )
        listView.setOnItemClickListener { _, _, position, _ ->
            val season = series.seasons[position]
            dialog.dismiss()
            showEpisodeDialog(season)
        }

        dialogView.findViewById<Button>(R.id.btnCloseSeasonDialog)
            .setOnClickListener { dialog.dismiss() }

        dialog.show()
    }

    // Afficher la popup des épisodes
    private fun showEpisodeDialog(season: Season) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_select_episode, null)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()

        val listView = dialogView.findViewById<ListView>(R.id.lvEpisodes)
        listView.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            season.episodes.map { "Episode ${it.number}" }
        )
        listView.setOnItemClickListener { _, _, position, _ ->
            val episode = season.episodes[position]
            dialog.dismiss()
            openPlayerActivity(episode)
        }

        dialogView.findViewById<Button>(R.id.btnCloseEpisodeDialog)
            .setOnClickListener { dialog.dismiss() }

        dialog.show()
    }

    // Ouvrir l'activité du lecteur vidéo
    private fun openPlayerActivity(episode: Episode) {
        if (episode.video_links.isNullOrEmpty()) {
            // Afficher une alerte si les liens vidéo sont absents
            AlertDialog.Builder(requireContext())
                .setTitle("Erreur")
                .setMessage("Aucun lien vidéo disponible pour cet épisode.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // Passer les liens vidéo à l'activité Player
        val intent = Intent(requireContext(), SeriesPlayerActivity::class.java)
        intent.putStringArrayListExtra("VIDEO_LINKS", ArrayList(episode.video_links))
        startActivity(intent)
    }
}
