package com.example.stream4life

data class Movie(
    val title: String,     // Titre du film
    val videoUrl: String,  // Lien embed de la vidéo
    val imageUrl: String   // URL de l'image du film
)
