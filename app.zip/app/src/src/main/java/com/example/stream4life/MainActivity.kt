package com.example.stream4life

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.stream4life.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val allMovies = mutableListOf<Movie>()
    private val displayedMovies = mutableListOf<Movie>()
    private var currentPage = 1
    private val moviesPerPage = 15

    companion object {
        private const val REQUEST_CODE_PERMISSION = 1001
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setTheme(R.style.DarkTheme) // Appliquer le thème sombre
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)

        // Demander les permissions d'accès au stockage
        requestStoragePermissions()

        // Charger les films depuis le fichier
        loadMovies()

        // Configuration du RecyclerView pour afficher les films
        val adapter = MovieAdapter(displayedMovies, ::onMovieClick, ::onDownloadClick)
        binding.recyclerView.layoutManager = GridLayoutManager(this, 3)
        binding.recyclerView.adapter = adapter

        // Afficher les films de la première page
        updateDisplayedMovies(adapter)

        // Gestion de la pagination
        binding.nextPageButton.setOnClickListener {
            if ((currentPage * moviesPerPage) < allMovies.size) {
                currentPage++
                updateDisplayedMovies(adapter)
            }
        }

        binding.previousPageButton.setOnClickListener {
            if (currentPage > 1) {
                currentPage--
                updateDisplayedMovies(adapter)
            }
        }

        // Barre de recherche
        binding.searchBar.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false

            override fun onQueryTextChange(newText: String?): Boolean {
                val filteredMovies = allMovies.filter {
                    it.title.contains(newText.toString(), ignoreCase = true)
                }
                if (newText.isNullOrEmpty()) {
                    updateDisplayedMovies(adapter)
                } else {
                    displayedMovies.clear()
                    displayedMovies.addAll(filteredMovies)
                    adapter.notifyDataSetChanged()
                }
                return true
            }
        })

        // Ajouter un clic sur le TextView pour naviguer vers l'activité des séries
        val seriesTextView: TextView = findViewById(R.id.seriesTextView)
        seriesTextView.setOnClickListener {
            // Lancer l'activité com.example.stream4life.com.example.stream4life.MainSeriesActivity
            val intent = Intent(this, MainSeriesActivity::class.java)
            startActivity(intent)
        }
    }

    private fun updateDisplayedMovies(adapter: MovieAdapter) {
        val startIndex = (currentPage - 1) * moviesPerPage
        val endIndex = (startIndex + moviesPerPage).coerceAtMost(allMovies.size)
        displayedMovies.clear()
        displayedMovies.addAll(allMovies.subList(startIndex, endIndex))
        adapter.notifyDataSetChanged()
        updatePaginationText()
    }

    @SuppressLint("SetTextI18n")
    private fun updatePaginationText() {
        val totalPages = (allMovies.size + moviesPerPage - 1) / moviesPerPage
        binding.paginationText.text = "Page $currentPage / $totalPages"
    }

    private fun onMovieClick(movie: Movie) {
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra("videoUrl", movie.videoUrl)
        startActivity(intent)
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun onDownloadClick(movie: Movie) {
        downloadVideoUsingYTDL(movie.title, movie.videoUrl)
    }

    private fun loadMovies() {
        try {
            val fileContent = assets.open("film_results.txt").bufferedReader().use { it.readText() }
            fileContent.lines().forEach { line ->
                val parts = line.split("-----")
                if (parts.size == 3) {
                    allMovies.add(Movie(parts[0].trim(), parts[1].trim(), parts[2].trim()))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun requestStoragePermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_CODE_PERMISSION)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun extractYTDLExecutable(): File {
        val outputDir = File(getExternalFilesDir(null), "yt-dlp") // Utilisation du répertoire des fichiers externes
        if (!outputDir.exists()) {
            outputDir.mkdirs() // Créer le répertoire si nécessaire
        }

        val inputStream: InputStream = assets.open("yt-dlp_linux") // Assurez-vous que le fichier yt-dlp_linux est dans /assets
        val outputFile = File(outputDir, "yt-dlp_linux")

        outputFile.outputStream().use { outputStream ->
            inputStream.copyTo(outputStream)
        }

        // Forcer les permissions d'exécution sur le fichier extrait
        if (!outputFile.setExecutable(true)) {
            Log.e("PermissionError", "Impossible de définir les permissions d'exécution")
        } else {
            Log.d("PermissionSuccess", "Le fichier a été rendu exécutable")
        }

        return outputFile
    }

    private fun forcePermissions(file: File) {
        try {
            val process = ProcessBuilder("chmod", "755", file.absolutePath) // 755 donne les permissions d'exécution
                .start()
            process.waitFor()
            Log.d("Permission", "Permissions ajustées avec succès")
        } catch (e: Exception) {
            Log.e("PermissionError", "Erreur lors de la modification des permissions : ${e.message}")
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun downloadVideoUsingYTDL(title: String, videoUrl: String) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val ytDLPExecutable = extractYTDLExecutable()

                // Créer un ProcessBuilder pour exécuter yt-dlp
                val process = ProcessBuilder(ytDLPExecutable.absolutePath, "-o", "${Environment.getExternalStorageDirectory()}/Download/$title.%(ext)s", videoUrl)
                    .directory(filesDir) // Exécuter depuis le répertoire de fichiers internes de l'application
                    .redirectErrorStream(true) // Fusionner les flux d'erreur et de sortie
                    .start()

                // Lire la sortie du processus (optionnel)
                val output = process.inputStream.bufferedReader().readText()
                Log.d("YTDL", output)

                // Attendre que le processus se termine
                process.waitFor()

                // Télécharger la vidéo dans le répertoire des téléchargements
                val uri = Uri.parse("file://${Environment.getExternalStorageDirectory()}/Download/$title.mp4")
                val request = DownloadManager.Request(uri).apply {
                    setTitle("Téléchargement : $title")
                    setDescription("Téléchargement de la vidéo en cours...")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "$title.mp4")
                }

                val downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                downloadManager.enqueue(request)

                Toast.makeText(this@MainActivity, "Téléchargement lancé pour $title", Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MainActivity, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
