package com.example.stream4life

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MovieViewModel : ViewModel() {

    private val _movies = MutableLiveData<List<Movie>>()
    val movies: LiveData<List<Movie>> = _movies

    // Méthode pour charger les films
    fun loadMovies() {
        // Remplir avec des données (par exemple depuis un fichier ou une API)
        val moviesList = listOf(
            Movie("Movie 1", "url1", "Description 1"),
            Movie("Movie 2", "url2", "Description 2")
            // Ajouter plus de films ici
        )
        _movies.value = moviesList
    }

    // Méthode pour filtrer les films en fonction de la recherche
    fun filterMovies(query: String) {
        val filteredList = _movies.value?.filter {
            it.title.contains(query, ignoreCase = true)
        } ?: emptyList()
        _movies.value = filteredList
    }
}
