import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.stream4life.R
import com.example.stream4life.Series

class SeriesAdapter(
    private val seriesList: List<Series>,
    private val onSeriesClick: (Series) -> Unit
) : RecyclerView.Adapter<SeriesAdapter.SeriesViewHolder>() {

    class SeriesViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.textViewSeriesTitle)
        val image: ImageView = view.findViewById(R.id.imageViewSeries)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeriesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_series_card, parent, false)
        return SeriesViewHolder(view)
    }

    override fun onBindViewHolder(holder: SeriesViewHolder, position: Int) {
        val series = seriesList[position]
        holder.title.text = series.title
        // Charger l'image (avec Glide ou Coil)
        holder.itemView.setOnClickListener { onSeriesClick(series) }
    }

    override fun getItemCount() = seriesList.size
}
