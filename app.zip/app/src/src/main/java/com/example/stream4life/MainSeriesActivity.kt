package com.example.stream4life

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.BufferedReader

// Classes de données
data class Episode(val number: String, val video_links: List<String>)
data class Season(val title: String, val episodes: List<Episode>)
data class Series(val title: String, val image_url: String, val seasons: List<Season>)

class MainSeriesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mainseries)

        val seriesList = fetchSeriesData()

        // Initialiser le RecyclerView
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewSeries)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = SeriesAdapter(seriesList) { series ->
            showSeasonDialog(series)
        }
    }

    // Charger les données JSON
    private fun fetchSeriesData(): List<Series> {
        val seriesList = mutableListOf<Series>()
        try {
            val inputStream = assets.open("series-results-formated.json")
            val json = inputStream.bufferedReader().use(BufferedReader::readText)
            val seriesListType = object : TypeToken<List<Series>>() {}.type
            seriesList.addAll(Gson().fromJson(json, seriesListType))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return seriesList
    }

    // Afficher la popup des saisons
    private fun showSeasonDialog(series: Series) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_select_season, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        val listView = dialogView.findViewById<ListView>(R.id.lvSeasons)
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, series.seasons.map { it.title })
        listView.setOnItemClickListener { _, _, position, _ ->
            val season = series.seasons[position]
            dialog.dismiss()
            showEpisodeDialog(season)
        }
        dialogView.findViewById<Button>(R.id.btnCloseSeasonDialog).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // Afficher la popup des épisodes
    private fun showEpisodeDialog(season: Season) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_select_episode, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        val listView = dialogView.findViewById<ListView>(R.id.lvEpisodes)
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, season.episodes.map { it.number })
        listView.setOnItemClickListener { _, _, position, _ ->
            val episode = season.episodes[position]
            dialog.dismiss()
            openPlayerActivity(episode)
        }
        dialogView.findViewById<Button>(R.id.btnCloseEpisodeDialog).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // Ouvrir l'activité du lecteur vidéo
    private fun openPlayerActivity(episode: Episode) {
        // Vérifier si les liens vidéo sont disponibles
        if (episode.video_links.isNullOrEmpty()) {
            // Affichez une alerte si les liens vidéo sont absents
            AlertDialog.Builder(this)
                .setTitle("Erreur")
                .setMessage("Aucun lien vidéo disponible pour cet épisode.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // Si les liens vidéo sont valides, passez à l'activité Player
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putStringArrayListExtra("VIDEO_LINKS", ArrayList(episode.video_links))
        startActivity(intent)
    }


    // Adapter pour les séries
class SeriesAdapter(
    private val seriesList: List<Series>,
    private val onSeriesClick: (Series) -> Unit
) : RecyclerView.Adapter<SeriesAdapter.SeriesViewHolder>() {

    class SeriesViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.textViewSeriesTitle)
        val image: ImageView = view.findViewById(R.id.imageViewSeries)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeriesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_series_card, parent, false)
        return SeriesViewHolder(view)
    }

    override fun onBindViewHolder(holder: SeriesViewHolder, position: Int) {
        val series = seriesList[position]
        holder.title.text = series.title
        // Charger l'image avec Glide
        Glide.with(holder.itemView.context)
            .load(series.image_url)
            .placeholder(R.drawable.placeholder_image) // Ajouter une icône de remplacement par défaut
            .into(holder.image)
        holder.itemView.setOnClickListener { onSeriesClick(series) }
    }

    override fun getItemCount() = seriesList.size
}}
