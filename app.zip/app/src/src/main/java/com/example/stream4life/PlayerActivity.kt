package com.example.stream4life
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ead.lib.nomoreadsonmywebviewplayer.NoMoreAdsWebView
import com.ead.lib.nomoreadsonmywebviewplayer.core.Blocker

class PlayerActivity : AppCompatActivity() {

    private lateinit var webView: NoMoreAdsWebView
    private var videoUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)  // Remplace par ton layout XML

        // Initialisation du bloqueur d'annonces
        Blocker.init(this)

        // Initialiser le WebView personnalisé
        webView = findViewById(R.id.web_view)  // Assure-toi que l'ID correspond à ton WebView dans le layout

        // Extraire l'URL de la vidéo depuis l'intent
        videoUrl = intent.getStringExtra("videoUrl") ?: "https://example.com"  // URL par défaut si rien n'est passé

        // Charger l'URL dans le WebView
        webView.loadUrl(videoUrl!!)
    }

    // Méthode pour fermer ou gérer d'autres interactions avec le WebView, si nécessaire
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()  // Si le WebView a un historique, on revient en arrière
        } else {
            super.onBackPressed()  // Sinon, on effectue le comportement par défaut (ferme l'activité)
        }
    }
}
