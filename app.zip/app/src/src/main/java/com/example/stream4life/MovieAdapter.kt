package com.example.stream4life

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

// Importer la classe Movie depuis son fichier
import com.example.stream4life.models.Movie

class MovieAdapter(
    private var movies: List<Movie>,
    private val onMovieClick: (Movie) -> Unit,
    private val onDownloadClick: (Movie) -> Unit
) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    fun updateMovies(newMovies: List<Movie>) {
        movies = newMovies
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_movie, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = movies[position]
        holder.bind(movie)
    }

    override fun getItemCount(): Int = movies.size

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val movieImage: ImageView = itemView.findViewById(R.id.movieImage)
        private val movieTitle: TextView = itemView.findViewById(R.id.movieTitle)
        private val downloadButton: ImageView = itemView.findViewById(R.id.downloadButton)

        fun bind(movie: Movie) {
            // Associer le titre
            movieTitle.text = movie.title

            // Charger l'image avec Glide
            Glide.with(itemView.context)
                .load(movie.imageUrl)
                .placeholder(R.drawable.placeholder_image) // Image par défaut
                .error(R.drawable.error_image) // Image en cas d'erreur
                .into(movieImage)

            // Action sur le clic de l'élément
            itemView.setOnClickListener { onMovieClick(movie) }

            // Action sur le clic du bouton de téléchargement
            downloadButton.setOnClickListener { onDownloadClick(movie) }
        }
    }
}
