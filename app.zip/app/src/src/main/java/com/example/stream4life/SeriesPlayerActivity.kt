package com.example.stream4life

import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class SeriesPlayerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series_player)

        val videoView = findViewById<VideoView>(R.id.videoView)
        val listViewLinks = findViewById<ListView>(R.id.listViewLinks)

        // Récupérer les liens vidéo depuis l'intent
        val videoLinks = intent.getStringArrayListExtra("VIDEO_LINKS") ?: emptyList<String>()

        // Adapter pour afficher les liens vidéo
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, videoLinks)
        listViewLinks.adapter = adapter

        // Événement sur le clic d'un lien vidéo
        listViewLinks.setOnItemClickListener { _, _, position, _ ->
            val selectedLink = videoLinks[position]
            playVideo(videoView, selectedLink)
        }

        // Lire automatiquement le premier lien vidéo si disponible
        if (videoLinks.isNotEmpty()) {
            playVideo(videoView, videoLinks[0])
        }
    }

    private fun playVideo(videoView: VideoView, url: String) {
        val uri = Uri.parse(url)
        videoView.setVideoURI(uri)
        videoView.setOnPreparedListener { mediaPlayer ->
            mediaPlayer.isLooping = true
            videoView.start()
        }
    }
}
