@file:Suppress("DEPRECATION")

pluginManagement {
    repositories {
        google() // Google repository pour AndroidX et autres dépendances
        mavenCentral() // Dépôt Maven central pour d'autres dépendances
        gradlePluginPortal() // Dépôt Gradle plugin portal pour les plugins
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google ()
        jcenter()
        mavenCentral()   // Keep Maven Central
        maven { url = uri("https://jitpack.io") }  // Add JitPack repository
        //noinspection JcenterRepositoryObsolete
        maven("https://chaquo.com/maven")


}
}

rootProject.name = "Stream4Life"
include(":app")
