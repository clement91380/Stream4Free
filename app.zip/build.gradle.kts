@file:Suppress("DEPRECATION")

buildscript {
    repositories {
        google() // Dépôt Google pour Android et plugins associés
        mavenCentral() // Dépôt Maven Central
        //noinspection JcenterRepositoryObsolete
        jcenter ()
        maven("https://chaquo.com/maven")

    }
    dependencies {
        // Dépendances du buildscript, comme les plugins Android
        classpath("com.android.tools.build:gradle:8.7.2") // Par exemple, la version de Gradle pour Android
        classpath ("org.jetbrains.kotlin:kotlin-gradle-plugin:2.0.0") // Remplacez par 2.0.0

    }

        // Add the dependency for the Google services Gradle plugin


    }







